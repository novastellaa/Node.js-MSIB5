for (let angka = 1; angka <= 10; angka++) {
    if (angka % 2) {
        console.log(angka);
    }
}