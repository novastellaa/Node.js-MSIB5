function hitung(angka1, angka2) {
    const a = angka1;
    const b = angka2;
    const pertambahan = a + b;
    console.log(pertambahan);
    const pengurangan = a - b;
    console.log(pengurangan);
    const perkalian = a * b;
    console.log(perkalian);
}

hitung(5, 5);