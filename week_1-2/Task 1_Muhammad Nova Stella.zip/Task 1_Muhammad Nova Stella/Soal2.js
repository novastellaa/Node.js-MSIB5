const panjang = 10;
const lebar = 5;

const luas = panjang * lebar;
console.log(luas);