const angkaPertama = 8;
const angkaKedua = 3;

const sisa = angkaPertama % angkaKedua;
console.log(sisa);