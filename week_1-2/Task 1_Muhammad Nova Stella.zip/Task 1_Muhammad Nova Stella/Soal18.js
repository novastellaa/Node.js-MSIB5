function hitungMundur(n) {
    for (; n >= 1; n--)
        console.log(n)
}

const n = 20;
const reverse = hitungMundur(n);

console.log(reverse)