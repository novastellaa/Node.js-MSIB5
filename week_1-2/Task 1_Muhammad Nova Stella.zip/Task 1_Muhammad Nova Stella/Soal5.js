let nilaiUjian = 90;

const lulus = nilaiUjian > 60;

if (nilaiUjian >= 60 && nilaiUjian <= 100) {
    console.log('Selamat anda lulus')
} else {
    console.log('Maaf, Anda belum lulus')
}