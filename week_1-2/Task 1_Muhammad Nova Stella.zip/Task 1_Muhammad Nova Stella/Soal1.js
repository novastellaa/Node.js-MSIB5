const nama = 'Muhammad Nova Stella';

console.log(nama);