function kaliDua(angka) {
    return angka * 2;

}

const angka = 10;

const hasilAngka = kaliDua(angka);
console.log(`hasilnya adalah ${hasilAngka}`);