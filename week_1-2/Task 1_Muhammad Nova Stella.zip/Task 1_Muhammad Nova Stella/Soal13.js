const namaDepan = 'Nova';
const namaBelakang = 'Stella';
const namaLengkap = `${namaDepan} ${namaBelakang}`;

console.log(namaLengkap);