const nilai = 30;

function aritmatika(nilai) {
    const hasil = nilai * 2
    return hasil;
}

const hasil = aritmatika(nilai);
console.log(hasil);