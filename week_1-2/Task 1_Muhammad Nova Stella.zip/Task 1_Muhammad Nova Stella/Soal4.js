const umur = 90;
const hasil = umur >= 18 ? 'Anda Sudah Dewasa' : 'Anda masih bocil';
console.log(hasil)
    // if (umur >= 18) {
    //     console.log('Anda sudah dewasa');
    // } else {
    //     console.log('Anda masih anak anak');
    // }