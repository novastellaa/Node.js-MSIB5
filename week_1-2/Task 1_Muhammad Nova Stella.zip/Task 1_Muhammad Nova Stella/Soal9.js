function anonim(angka) {
    return angka - 2;
}
const angka = 5;
const hasil = anonim(angka);
console.log(`hasilnya adalah ${hasil}`);