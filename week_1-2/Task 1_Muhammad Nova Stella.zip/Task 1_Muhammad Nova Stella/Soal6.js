function hitungLuas(panjang, lebar) {
    const luas = panjang * lebar;
    return luas;
}

const panjang = 5;
const lebar = 10;

const hasilLuas = hitungLuas(panjang, lebar);
console.log("Luas persegi panjang adalah: " + hasilLuas);