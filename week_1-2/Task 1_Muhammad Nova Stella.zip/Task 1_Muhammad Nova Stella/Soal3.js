const kota = 'Srabaya';
const negara = 'Indonesia';

console.log(`kota ${kota} berada di negara ${negara}`);