function sapa(nama) {
    return (`halo, ${nama}!`)
}

const nama = 'muhammad nova stella';
const sapaan = sapa(nama);
console.log(sapaan);