function hitungPangkat(basis, eksponen) {
    return basis ** eksponen;
}
const basis = 2;
const eksponen = 5;
const hasil = hitungPangkat(basis, eksponen);

console.log(hasil);